package com.funkmakerz.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioTrack;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    int ink=Color.rgb(29,29,43), purple=Color.rgb(116,86,246), muted=Color.rgb(112,112,132), bg=Color.rgb(247,247,252);
    LinearLayout root, content, nav;
    EditText prompt, chatInput, searchInput;
    TextView status, trackTitle, chatLog;
    String currentPrompt="", currentName="My Funk Beat";
    ArrayList<String> projects=new ArrayList<>();
    SharedPreferences prefs;
    ExecutorService worker=Executors.newSingleThreadExecutor();
    byte[] lastWav=null;

    @Override public void onCreate(Bundle b){ super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        prefs=getSharedPreferences("funkmakerz",MODE_PRIVATE);
        Set<String> saved=prefs.getStringSet("projects",new LinkedHashSet<String>());
        projects=new ArrayList<>(saved);
        showHome();
    }

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    TextView button(String label, boolean primary, Runnable click){
        TextView t=text(label,14,primary?Color.WHITE:ink,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(16),dp(13),dp(16),dp(13));
        t.setBackground(shape(primary?purple:Color.WHITE,16)); t.setElevation(dp(primary?2:0));
        t.setOnClickListener(v->{t.animate().scaleX(.97f).scaleY(.97f).setDuration(70).withEndAction(()->t.animate().scaleX(1).scaleY(1).setDuration(90).start()).start();click.run();});
        return t;
    }
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(14);e.setTextColor(ink);e.setHintTextColor(muted);e.setPadding(dp(14),dp(12),dp(14),dp(12));e.setBackground(shape(Color.WHITE,14));return e;}
    void start(String title,String subtitle){
        root=column();root.setBackgroundColor(bg);setContentView(root);
        LinearLayout header=column();header.setPadding(dp(20),dp(18),dp(20),dp(12));
        TextView brand=text("♫  FUNK MAKER Z",13,purple,true);header.addView(brand);
        TextView h=text(title,27,ink,true);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(8);header.addView(h,hp);
        if(subtitle!=null){TextView st=text(subtitle,13,muted,false);header.addView(st);}
        root.addView(header);
        ScrollView scroll=new ScrollView(this);content=column();content.setPadding(dp(18),dp(4),dp(18),dp(20));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setPadding(dp(8),dp(8),dp(8),dp(8));nav.setBackgroundColor(Color.WHITE);
        String[] names={"Studio","AI Chat","Search","Library"};
        Runnable[] acts={()->showHome(),()->showChat(),()->showSearch(),()->showLibrary()};
        for(int i=0;i<names.length;i++){final int j=i;TextView n=text(names[i],12,muted,true);n.setGravity(Gravity.CENTER);n.setPadding(dp(4),dp(12),dp(4),dp(12));n.setOnClickListener(v->acts[j].run());nav.addView(n,new LinearLayout.LayoutParams(0,-2,1));}
        root.addView(nav);
    }
    void card(View v){LinearLayout box=column();box.setPadding(dp(16),dp(15),dp(16),dp(15));box.setBackground(shape(Color.WHITE,20));box.addView(v);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(12);content.addView(box,p);}
    void gap(int h){View v=new View(this);content.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    void showHome(){
        start("Make your next funk.","Create a beat, refine your idea, and save your projects.");
        LinearLayout hero=column();hero.setPadding(dp(18),dp(18),dp(18),dp(18));hero.setBackground(shape(Color.rgb(29,25,55),22));
        hero.addView(text("YOUR SOUND. YOUR RULES.",11,Color.rgb(190,178,255),true));
        TextView big=text("Build a beat\nfrom an idea.",25,Color.WHITE,true);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(8);hero.addView(big,bp);
        TextView desc=text("Offline beat generator • Save locally • Share your prompts",12,Color.rgb(220,218,238),false);hero.addView(desc);
        LinearLayout.LayoutParams hpar=new LinearLayout.LayoutParams(-1,-2);hpar.bottomMargin=dp(14);content.addView(hero,hpar);
        TextView label=text("Describe your funk",16,ink,true);content.addView(label);gap(8);
        prompt=edit("e.g. aggressive Brazilian funk, deep bass, fast drums");
        prompt.setMinLines(3);prompt.setGravity(Gravity.TOP);content.addView(prompt,new LinearLayout.LayoutParams(-1,-2));
        gap(10);
        TextView note=text("The first version synthesizes a simple original drum-and-bass loop on your device. Full AI music generation will need a connected music-generation service.",12,muted,false);content.addView(note);gap(12);
        content.addView(button("✦  Create beat",true,()->createBeat()));
        gap(10);
        content.addView(button("Chat to refine your idea",false,()->showChat()));
        gap(18);
        content.addView(text("QUICK STARTS",12,muted,true));gap(8);
        String[] chips={"Aggressive Brazilian funk","Dark sigma instrumental","Fast phonk-style drums"};
        for(String c:chips){TextView ch=button(c,false,()->{prompt.setText(c);});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);content.addView(ch,p);}
    }
    void createBeat(){
        currentPrompt=prompt.getText().toString().trim();if(currentPrompt.isEmpty())currentPrompt="Brazilian funk instrumental, punchy kick, snare and bass";
        currentName=makeName(currentPrompt);statusText("Generating a 12-second demo loop on your device…");
        worker.execute(()->{byte[] wav=makeWav(currentPrompt);runOnUiThread(()->{lastWav=wav;saveProject(currentName+" — "+currentPrompt);showTrack();});});
    }
    String makeName(String s){String x=s.split("[,.!?]")[0].trim();if(x.length()>25)x=x.substring(0,25);return x.isEmpty()?"My Funk Beat":x;}
    void statusText(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    byte[] makeWav(String desc){
        int sr=22050, seconds=12, n=sr*seconds; short[] samples=new short[n];Random r=new Random(1234);
        // Deterministic, locally synthesized 4/4 groove with kick, snare, hats and bass.
        for(int i=0;i<n;i++){double t=i/(double)sr;double beat=t*2.0;int b=(int)Math.floor(beat);double phase=beat-b;double val=0;
            // kick on beats 0 and 2
            if((b%4==0||b%4==2)&&phase<0.22){double e=Math.exp(-phase*20);val+=Math.sin(2*Math.PI*(48+80*Math.exp(-phase*18))*t)*e*.75;}
            // snare on beats 1 and 3
            if((b%4==1||b%4==3)&&phase<0.16){double e=Math.exp(-phase*24);val+=(r.nextDouble()*2-1)*e*.28;}
            // hats on eighth notes
            if(phase<0.035){val+=(r.nextDouble()*2-1)*.10*Math.exp(-phase*70);}
            // bass pulse
            if(phase<0.32){double f=(b%4==2||b%4==3)?65.41:55.0;val+=Math.sin(2*Math.PI*f*t)*Math.exp(-phase*5)*.18;}
            // subtle clipping protection and fade
            double fade=Math.min(1,Math.min(t/0.03,(seconds-t)/0.08));samples[i]=(short)(Math.max(-.95,Math.min(.95,val))*Math.max(0,fade)*32767);
        }
        ByteBuffer out=ByteBuffer.allocate(44+n*2).order(ByteOrder.LITTLE_ENDIAN);
        out.put(new byte[]{'R','I','F','F'});out.putInt(36+n*2);out.put(new byte[]{'W','A','V','E','f','m','t',' '});out.putInt(16);out.putShort((short)1);out.putShort((short)1);out.putInt(sr);out.putInt(sr*2);out.putShort((short)2);out.putShort((short)16);out.put(new byte[]{'d','a','t','a'});out.putInt(n*2);for(short s:samples)out.putShort(s);return out.array();
    }
    void showTrack(){
        start("Your beat is ready","A simple original loop synthesized locally — not a full AI-produced song.");
        LinearLayout art=column();art.setPadding(dp(18),dp(22),dp(18),dp(22));art.setBackground(shape(Color.rgb(29,25,55),22));
        art.addView(text("♫  ORIGINAL DEMO LOOP",11,Color.rgb(190,178,255),true));gapIn(art,8);
        art.addView(text(currentName,23,Color.WHITE,true));gapIn(art,8);
        art.addView(text("12 seconds • WAV • Created on device",12,Color.rgb(220,218,238),false));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(14);content.addView(art,p);
        content.addView(button("▶  Play demo loop",true,()->playWav(lastWav)));
        gap(10);content.addView(button("⬇  Download WAV to phone",false,()->downloadWav()));
        gap(10);content.addView(button("Share track idea",false,()->shareText(currentName+"\n"+currentPrompt+"\nCreated with Funk Maker Z.")));
        gap(10);content.addView(button("Refine in AI Chat",false,()->showChat()));
        gap(14);TextView t=text("AI upgrade note: the current build makes a basic synthesized loop. Real text-to-music generation and detailed audio edits need an external music AI API and a secure backend.",12,muted,false);content.addView(t);
    }
    void gapIn(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    void playWav(byte[] wav){
        if(wav==null){statusText("Create a beat first.");return;}
        worker.execute(()->{try{int offset=44;int len=wav.length-offset;AudioTrack track=new AudioTrack(AudioManager.STREAM_MUSIC,22050,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT,len,AudioTrack.MODE_STATIC);track.write(wav,offset,len);track.play();Thread.sleep(12000);track.release();}catch(Exception e){runOnUiThread(()->statusText("Playback could not start."));}});
    }
    void downloadWav(){
        if(lastWav==null){statusText("Create a beat first.");return;}
        try{
            android.content.ContentValues values=new android.content.ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,currentName.replaceAll("[^a-zA-Z0-9_-]","_")+".wav");values.put(MediaStore.MediaColumns.MIME_TYPE,"audio/wav");values.put(MediaStore.MediaColumns.RELATIVE_PATH,android.os.Environment.DIRECTORY_DOWNLOADS+"/Funk Maker Z");
            Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
            if(uri==null)throw new IOException("Could not create download");
            OutputStream os=getContentResolver().openOutputStream(uri);os.write(lastWav);os.close();statusText("Saved to Downloads/Funk Maker Z");
        }catch(Exception e){statusText("Download failed: "+e.getMessage());}
    }
    void showChat(){
        start("Music AI Chat","Describe changes. This MVP helps refine your prompt; AI audio editing requires an external service.");
        TextView intro=text("Try: “make the bass heavier”, “faster drums”, or “make it darker”. The app updates your track prompt locally for now.",13,muted,false);content.addView(intro);gap(12);
        chatLog=text("Funk Maker Z: Hey! Tell me what sound you're aiming for.",14,ink,false);chatLog.setPadding(dp(14),dp(14),dp(14),dp(14));chatLog.setBackground(shape(Color.WHITE,16));content.addView(chatLog);gap(12);
        chatInput=edit("Type a change or music idea…");chatInput.setMinLines(2);chatInput.setGravity(Gravity.TOP);content.addView(chatInput);gap(8);
        content.addView(button("Send message",true,()->sendChat()));
        gap(10);content.addView(button("Use refined prompt in Studio",false,()->{showHome();prompt.setText(currentPrompt);}));
    }
    void sendChat(){
        String msg=chatInput.getText().toString().trim();if(msg.isEmpty())return;
        String lower=msg.toLowerCase(Locale.ROOT);
        if(lower.contains("bass"))currentPrompt+="; heavier bass";
        else if(lower.contains("fast")||lower.contains("faster")||lower.contains("tempo"))currentPrompt+="; faster tempo";
        else if(lower.contains("dark"))currentPrompt+="; darker mood";
        else if(lower.contains("snare")||lower.contains("drum"))currentPrompt+="; stronger drums";
        else currentPrompt+="; "+msg;
        String response="Got it — your working prompt is now:\n\n"+currentPrompt+"\n\nNote: I updated the prompt locally. Actual audio remixing by AI isn't connected in this first version.";
        chatLog.setText("You: "+msg+"\n\nFunk Maker Z: "+response);chatInput.setText("");saveProject(currentName+" — "+currentPrompt);
    }
    void showSearch(){
        start("Find music","Search the web for music or funk tracks. Results open in your browser.");
        searchInput=edit("Search Brazilian funk, phonk, or a song…");content.addView(searchInput);gap(10);
        content.addView(button("Search the web",true,()->{String q=searchInput.getText().toString().trim();if(q.isEmpty())q="Brazilian funk music";try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(q+" music"))));}catch(Exception e){statusText("Could not open browser.");}}));
        gap(12);TextView note=text("This searches public web results; it does not download copyrighted songs. For licensed catalog search and track previews, connect a music catalog API.",12,muted,false);content.addView(note);
        gap(16);content.addView(button("Search original music ideas in AI Chat",false,()->showChat()));
    }
    void showLibrary(){
        start("My Library","Projects are stored on this device.");
        if(projects.isEmpty()){TextView empty=text("No saved projects yet. Create a beat or save a prompt in AI Chat.",14,muted,false);content.addView(empty);}
        else for(String p:projects){LinearLayout item=column();item.addView(text(p,14,ink,true));gapIn(item,8);item.addView(button("Share prompt",false,()->shareText(p)));card(item);}
        gap(12);content.addView(button("Clear saved projects",false,()->{projects.clear();persist();showLibrary();}));
        TextView note=text("Local storage only in this version. Accounts and cloud sync need an authentication/database service.",12,muted,false);content.addView(note);
    }
    void saveProject(String s){if(s==null||s.trim().isEmpty())return;projects.remove(s);projects.add(0,s);while(projects.size()>50)projects.remove(projects.size()-1);persist();}
    void persist(){prefs.edit().putStringSet("projects",new LinkedHashSet<>(projects)).apply();}
    void shareText(String s){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(i,"Share with friends"));}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdownNow();}
}
