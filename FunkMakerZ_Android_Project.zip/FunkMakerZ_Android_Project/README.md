# Funk Maker Z — Android MVP

## What works now
- Native Android app UI with Studio, AI Chat, Search, and Library tabs.
- Creates a simple 12-second synthesized drum-and-bass loop offline.
- Plays the loop and downloads a WAV file into `Downloads/Funk Maker Z`.
- Saves project prompts locally on the device.
- Chat-like prompt refinement using local rules (not a connected AI model).
- Web music search opens the browser.
- Shares prompts using Android's share sheet.
- Basic button animations.

## Important limits
This is a functional prototype, not a complete AI music generator:
- Full AI text-to-music generation and real audio remixing require an external music-generation API and a secure backend.
- Real AI chat requires an LLM API and backend.
- Search within a licensed music catalogue requires a music-search/catalogue API. Web search is used in this MVP.
- User accounts and cloud-synced projects require an authentication/database provider.
- The current app uses local-only storage; no account or cloud sync is implemented.
- The generated WAV is a basic synthesized loop, not a polished full-length track.

Do not put a secret provider API key directly inside an Android APK. Use a backend to protect keys.

## Build APK
1. Install Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Allow Gradle sync and install the Android SDK for API 35.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK on your Android phone.

This source project has not been compiled or tested on a physical device in this environment. Gradle may need internet access to download Android build dependencies.
