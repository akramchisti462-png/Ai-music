# Build the APK using a phone and GitHub Actions

This project includes `.github/workflows/build-apk.yml`, which asks GitHub's hosted build computer to build the debug APK.

1. Sign in to GitHub and create a new **public or private repository** named `FunkMakerZ`.
2. Upload the *contents* of this ZIP into the repository (the `app`, `build.gradle`, `settings.gradle`, `gradle.properties`, and `.github` folder should be at the repository root, not inside an extra nested folder).
3. Open the repository's **Actions** tab. If prompted, enable Actions.
4. Select **Build Funk Maker Z APK** and tap **Run workflow**. You can also let it run after pushing the files to the `main` branch.
5. Wait for the workflow to finish successfully, open that run, and scroll to **Artifacts**.
6. Download `FunkMakerZ-debug-apk`, extract it, and install `app-debug.apk` on your Android phone. Android may ask you to allow installing apps from that source.

Notes:
- This creates a debug APK for testing, not a Play Store release-signed APK.
- GitHub Actions availability and minutes depend on your GitHub account/repository settings.
- This process requires a GitHub account and internet access; the APK is not already included in this ZIP.
